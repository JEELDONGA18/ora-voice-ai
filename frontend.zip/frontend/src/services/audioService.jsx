// services/audioService.js

import { WS_BASE_URL } from "./apiService";

let ws = null;

/**
 * Start a voice session with backend
 * Backend now ONLY handles:
 * - user_text (string)
 * - submit
 * - ai_text
 * - tts audio stream
 */
export function startVoiceSession({
  sessionId,
  onAudioChunk,
  onTTSEnd,
  onAIText,
}) {
  ws = new WebSocket(`${WS_BASE_URL}/api/voice/${sessionId}`);
  ws.binaryType = "arraybuffer";

  ws.onopen = () => {
    console.log("🎤 WebSocket connected");
  };

  ws.onmessage = (event) => {
    // 🔊 Binary TTS audio
    if (event.data instanceof ArrayBuffer) {
      onAudioChunk?.(event.data);
      return;
    }

    // 📩 JSON message
    const data = JSON.parse(event.data);

    if (data.type === "ai_text") {
      onAIText?.(data.text);
    }

    if (data.type === "tts_end") {
      onTTSEnd?.();
    }
  };

  ws.onerror = (err) => {
    console.error("WebSocket error", err);
  };

  ws.onclose = () => {
    console.log("🔒 WebSocket closed");
  };
}

/**
 * Send user text (from Web Speech API)
 */
export function sendUserText(text) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(
      JSON.stringify({
        type: "user_text",
        text,
      })
    );
  }
}

/**
 * Submit text (Enter key)
 */
export function submitText() {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: "submit" }));
  }
}

/**
 * Close session completely
 */
export function closeVoiceSession() {
  if (ws) {
    ws.close();
    ws = null;
  }
}