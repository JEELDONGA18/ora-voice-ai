// voiceApi.js
