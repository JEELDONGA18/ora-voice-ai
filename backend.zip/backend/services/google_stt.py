import os
from google.cloud import speech

# Google uses a JSON credentials file
GOOGLE_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
print("GOOGLE CREDS:", os.getenv("GOOGLE_APPLICATION_CREDENTIALS"))

def transcribe_audio(wav_bytes: bytes) -> str:
    client = speech.SpeechClient()

    audio = speech.RecognitionAudio(content=wav_bytes)

    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=16000,
        language_code="en-US",  # change if needed
        enable_automatic_punctuation=True,
    )

    response = client.recognize(
        config=config,
        audio=audio
    )

    if not response.results:
        return ""

    return response.results[0].alternatives[0].transcript